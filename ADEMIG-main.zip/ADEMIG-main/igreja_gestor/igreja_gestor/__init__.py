# Conteúdo do arquivo /igreja_gestor/igreja_gestor/__init__.py

# Este arquivo indica que o diretório igreja_gestor é um pacote Python.