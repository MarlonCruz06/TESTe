from django.apps import AppConfig

class MembrosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'membros'
    verbose_name = 'Membros'