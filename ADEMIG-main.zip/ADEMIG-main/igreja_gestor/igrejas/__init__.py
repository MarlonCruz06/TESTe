# Conteúdo do arquivo /igreja_gestor/igreja_gestor/igrejas/__init__.py

# Este arquivo é intencionalmente deixado em branco.